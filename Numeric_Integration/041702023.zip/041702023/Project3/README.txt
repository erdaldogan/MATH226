
1-) Open Terminal and navigate to location where 'Numerical_Integration.jar' is downloaded
(041702023/Project3/Source/Numerical_Integration.jar)

2-) Run the .jar file by running the command 'java -jar Numerical_Integration.jar'

3-) You will be greeted with the function selection pane. Which is;
"
	Choose the function:
	[1]	4 / (1 + x^2)
	[2]	√x * log(x)

	Enter the function index (1-2):
"

Choose by typing the index of the function you wish

4-) Then you will be asked to enter the limits of the integration, enter lower limit first, then the upper limit.

"
	Enter the interval:
	Lower Bound:
	x
	Upper Bound:
	x
"

5-) After entering the limits of integration, programs asks you how many parts will the function be divided into? Type and integer value.

6-) If you have entered reasonable values up until now, you should see the approximation of the integral calculated with both midpoint and trapezoid rules.