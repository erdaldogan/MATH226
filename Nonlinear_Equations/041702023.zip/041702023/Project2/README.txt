
1-) Open Terminal and navigate to location where 'Nonlinear.jar' is downloaded

2-) Run the .jar file by running the command 'java -jar Nonlinear.jar'

3-) You will be greeted with the function selection pane. Which is;
"
Choose the function:
[1]	x^3 - 2x - 5
[2]	e^(-x) - x
[3]	xsin(x) - 1
[4]	x^3 - 3x^2 + 3x - 1
[5]	0.5 - xe^(-x^2)
[6]	x^2 + 4cos(x)
[7]	x^4 - 14x^3 + 60x^2 - 70x

Enter the function index (1-7):
"
Choose by typing the index of the function you wish

4-) Then you will be asked to choose which operation you want to perform. Root finding or optimization;
"
Choose the operation:
[1]	Find the roots of the function (Secant & Bisection Method)
[2]	Find the minimum (Newton's Method)
Enter the operation index (1-2):
"
Choose the operation just like the function.

5-) Depending on your selections, you will be prompted to enter your initial guess(es). Just follow the instructions of the program. It is self explanatory. 